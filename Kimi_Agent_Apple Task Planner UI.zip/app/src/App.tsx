import { useEffect } from 'react';
import { AppProvider, useApp } from '@/hooks/useAppContext';
import { MacOSWindow } from '@/components/macos/MacOSWindow';
import { IOSFrame } from '@/components/ios/IOSFrame';
import './App.css';

function AppContent() {
  const { state } = useApp();

  useEffect(() => {
    const root = document.documentElement;
    if (state.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [state.theme]);

  return (
    <div className="min-h-screen w-full" style={{ background: state.theme === 'dark' ? '#0d0d0f' : '#E8E8ED' }}>
      {/* macOS Desktop Section */}
      <section className="w-full flex flex-col items-center justify-center py-8 px-4">
        <p className="text-[13px] text-muted-foreground mb-4 font-medium">macOS Desktop</p>
        <div className="w-full max-w-[1280px]" style={{ height: 'min(calc(100vh - 100px), 800px)' }}>
          <MacOSWindow />
        </div>
      </section>

      {/* Divider */}
      <div className="w-full flex justify-center py-4">
        <div className="w-16 h-1 rounded-full bg-muted-foreground/20" />
      </div>

      {/* iOS Companion Section */}
      <section className="w-full flex flex-col items-center justify-center py-8 px-4">
        <IOSFrame />
      </section>

      {/* Footer */}
      <footer className="text-center py-6 text-[12px] text-muted-foreground">
        <p>Focus — Personal Task Planner Design Concept</p>
        <p className="mt-1">SwiftUI Multiplatform Reference</p>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
