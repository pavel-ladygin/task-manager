import { useState } from 'react';
import { Plus, Calendar, Flag, Folder } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';

interface QuickAddFieldProps {
  projectId?: string | null;
}

export function QuickAddField({ projectId }: QuickAddFieldProps) {
  const [focused, setFocused] = useState(false);
  const [text, setText] = useState('');
  const { state } = useApp();
  const project = projectId ? state.projects.find(p => p.id === projectId) : null;

  return (
    <div
      className={`flex items-center h-10 px-3 rounded-lg transition-all duration-200 ${
        focused ? 'bg-background shadow-sm border border-border' : 'bg-secondary'
      }`}
    >
      <Plus size={16} className="flex-shrink-0 mr-2" style={{ color: 'var(--accent-color)' }} />
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => { if (!text) setFocused(false); }}
        placeholder="Add a task..."
        className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
      />
      {focused && (
        <div className="flex items-center gap-1.5 ml-2 animate-in fade-in duration-200">
          {project && (
            <button className="p-1 rounded hover:bg-secondary transition-colors">
              <Folder size={14} style={{ color: project.color }} />
            </button>
          )}
          <button className="p-1 rounded hover:bg-secondary transition-colors">
            <Calendar size={14} className="text-muted-foreground" />
          </button>
          <button className="p-1 rounded hover:bg-secondary transition-colors">
            <Flag size={14} className="text-muted-foreground" />
          </button>
        </div>
      )}
    </div>
  );
}
