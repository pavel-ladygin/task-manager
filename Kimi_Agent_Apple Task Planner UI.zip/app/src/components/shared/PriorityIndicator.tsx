import { Flag } from 'lucide-react';
import type { Priority } from '@/types';
import { useApp } from '@/hooks/useAppContext';

interface PriorityIndicatorProps {
  priority: Priority;
  variant?: 'dot' | 'flag';
  size?: number;
}

const priorityColors: Record<Priority, string> = {
  none: 'transparent',
  low: '#8C8C8C',
  medium: '#FAAD14',
  high: '#D4380D',
  urgent: '#D4380D',
};

const priorityColorsDark: Record<Priority, string> = {
  none: 'transparent',
  low: '#8E8E93',
  medium: '#FFC53D',
  high: '#FF7875',
  urgent: '#FF7875',
};

export function PriorityIndicator({ priority, variant = 'dot', size = 8 }: PriorityIndicatorProps) {
  const { state } = useApp();
  if (priority === 'none' && variant === 'dot') return null;

  const colors = state.theme === 'dark' ? priorityColorsDark : priorityColors;
  const color = colors[priority];

  if (variant === 'flag') {
    return (
      <Flag
        size={16}
        className="flex-shrink-0"
        style={{ color: priority === 'none' ? 'hsl(var(--muted-foreground))' : color }}
        fill={priority !== 'none' ? color : 'none'}
      />
    );
  }

  return (
    <span
      className="flex-shrink-0 rounded-full"
      style={{
        width: size,
        height: size,
        backgroundColor: color,
        boxShadow: priority === 'urgent' ? `0 0 0 2px ${color}40` : 'none',
      }}
    />
  );
}
