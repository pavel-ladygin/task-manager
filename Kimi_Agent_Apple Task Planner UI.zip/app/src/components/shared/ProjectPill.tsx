import { useApp } from '@/hooks/useAppContext';

interface ProjectPillProps {
  projectId: string | null;
  interactive?: boolean;
  onClick?: () => void;
}

export function ProjectPill({ projectId, interactive = false, onClick }: ProjectPillProps) {
  const { state } = useApp();
  const project = projectId ? state.projects.find(p => p.id === projectId) : null;
  if (!project) return null;

  const isDark = state.theme === 'dark';
  const color = isDark ? project.colorDark : project.color;

  return (
    <span
      onClick={onClick}
      className={`inline-flex items-center h-5 px-2 rounded-full text-xs font-medium ${interactive ? 'cursor-pointer hover:opacity-80' : ''}`}
      style={{
        backgroundColor: `${color}26`,
        color: color,
      }}
    >
      {project.name}
    </span>
  );
}
