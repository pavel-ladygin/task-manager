import { format, parseISO, isPast, isToday } from 'date-fns';
import { Clock, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Task } from '@/types';
import { useApp } from '@/hooks/useAppContext';
import { Checkbox } from './Checkbox';
import { PriorityIndicator } from './PriorityIndicator';
import { ProjectPill } from './ProjectPill';

interface TaskRowProps {
  task: Task;
  selected?: boolean;
  onSelect?: () => void;
  compact?: boolean;
  hideProject?: boolean;
  className?: string;
}

export function TaskRow({ task, selected = false, onSelect, compact = false, hideProject = false, className = '' }: TaskRowProps) {
  const { dispatch } = useApp();
  const isCompleted = task.status === 'done';
  const isOverdue = task.dueDate && isPast(parseISO(task.dueDate)) && !isToday(parseISO(task.dueDate)) && !isCompleted;

  const handleToggle = () => {
    dispatch({ type: 'TOGGLE_TASK_COMPLETE', taskId: task.id });
  };

  const scheduledTime = task.scheduledDate && (() => {
    const date = parseISO(task.scheduledDate);
    if (isToday(date)) return format(date, 'HH:mm');
    return format(date, 'MMM d');
  })();

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.2 }}
      onClick={onSelect}
      className={`group relative flex items-center cursor-pointer transition-colors duration-150 ${
        compact ? 'h-9 px-3' : 'h-11 px-4'
      } ${selected ? 'bg-[var(--accent-color)]/[0.08]' : 'hover:bg-secondary'} ${className}`}
    >
      {/* Selection indicator */}
      {selected && (
        <motion.div
          layoutId="selection-indicator"
          className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full"
          style={{ backgroundColor: 'var(--accent-color)' }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        />
      )}

      {/* Overdue indicator */}
      {isOverdue && (
        <div
          className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full"
          style={{ backgroundColor: 'var(--overdue)' }}
        />
      )}

      <div className="flex items-center gap-2.5 flex-1 min-w-0">
        <Checkbox checked={isCompleted} onToggle={handleToggle} size={compact ? 18 : 20} />

        <PriorityIndicator priority={task.priority} variant="dot" size={compact ? 6 : 8} />

        <span
          className={`flex-1 truncate text-[13px] transition-colors duration-200 ${
            isCompleted
              ? 'text-[var(--completed)] line-through'
              : 'text-foreground'
          } ${selected ? 'font-medium' : ''}`}
        >
          {task.title}
        </span>
      </div>

      <div className="flex items-center gap-2 ml-3 flex-shrink-0">
        {!hideProject && task.projectId && (
          <ProjectPill projectId={task.projectId} />
        )}

        {scheduledTime && (
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock size={10} />
            {scheduledTime}
          </span>
        )}

        {task.dueDate && (
          <span
            className={`flex items-center gap-1 text-xs ${
              isOverdue ? 'text-[var(--overdue)]' : 'text-muted-foreground'
            }`}
          >
            <Calendar size={10} />
            {format(parseISO(task.dueDate), 'MMM d')}
          </span>
        )}
      </div>
    </motion.div>
  );
}
