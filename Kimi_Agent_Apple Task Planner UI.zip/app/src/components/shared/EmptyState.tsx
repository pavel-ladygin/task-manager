import type { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  subtitle: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({ icon: Icon, title, subtitle, actionLabel, onAction }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-8 text-center">
      <Icon size={48} className="text-muted-foreground/30 mb-3" strokeWidth={1.5} />
      <h3 className="text-[15px] font-medium text-muted-foreground mb-1">{title}</h3>
      <p className="text-xs text-muted-foreground/70 mb-4">{subtitle}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="text-sm font-medium px-4 py-1.5 rounded-full"
          style={{ color: 'var(--accent-color)' }}
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
