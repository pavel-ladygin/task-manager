import { motion } from 'framer-motion';

interface CheckboxProps {
  checked: boolean;
  onToggle: () => void;
  size?: number;
}

export function Checkbox({ checked, onToggle, size = 20 }: CheckboxProps) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onToggle(); }}
      className="relative flex-shrink-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] focus:ring-offset-1 rounded-full"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} viewBox="0 0 20 20" fill="none">
        <motion.circle
          cx="10" cy="10" r="9"
          stroke={checked ? 'var(--success)' : 'hsl(var(--muted-foreground))'}
          strokeWidth="1.5"
          fill={checked ? 'var(--success)' : 'transparent'}
          initial={false}
          animate={{
            stroke: checked ? 'var(--success)' : 'hsl(var(--muted-foreground))',
            fill: checked ? 'var(--success)' : 'transparent',
          }}
          transition={{ duration: 0.15 }}
        />
        {checked && (
          <motion.path
            d="M6 10L8.5 12.5L14 7"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.15, delay: 0.05 }}
          />
        )}
      </svg>
    </button>
  );
}
