import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

interface SectionHeaderProps {
  title: string;
  count: number;
  defaultCollapsed?: boolean;
  overdueTint?: boolean;
  onToggle?: (collapsed: boolean) => void;
}

export function SectionHeader({ title, count, defaultCollapsed = false, overdueTint = false, onToggle }: SectionHeaderProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  const toggle = () => {
    const next = !collapsed;
    setCollapsed(next);
    onToggle?.(next);
  };

  return (
    <div
      className={`sticky top-0 z-10 flex items-center h-9 px-4 cursor-pointer select-none transition-colors ${
        overdueTint ? 'bg-red-500/5' : 'bg-background'
      }`}
      onClick={toggle}
    >
      <motion.div
        animate={{ rotate: collapsed ? 0 : 90 }}
        transition={{ duration: 0.15 }}
        className="mr-1.5"
      >
        <ChevronRight size={12} className="text-muted-foreground" />
      </motion.div>
      <h3 className="text-sm font-medium text-foreground">{title}</h3>
      <span className="ml-1.5 text-xs text-muted-foreground">({count})</span>
    </div>
  );
}
