import { motion } from 'framer-motion';
import type { TaskStatus } from '@/types';

interface StatusPillProps {
  status: TaskStatus;
  active: boolean;
  onClick: () => void;
}

const statusLabels: Record<TaskStatus, string> = {
  inbox: 'Inbox',
  planned: 'Planned',
  in_progress: 'In Progress',
  done: 'Done',
  cancelled: 'Cancelled',
};

export function StatusPill({ status, active, onClick }: StatusPillProps) {
  return (
    <motion.button
      onClick={onClick}
      className={`h-7 px-3 rounded-full text-xs font-medium cursor-pointer transition-colors duration-150 ${
        active
          ? 'text-white'
          : 'bg-secondary text-muted-foreground hover:text-foreground'
      }`}
      style={active ? { backgroundColor: 'var(--accent-color)' } : {}}
      whileTap={{ scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
    >
      {statusLabels[status]}
    </motion.button>
  );
}
