import { AnimatePresence } from 'framer-motion';
import { useApp } from '@/hooks/useAppContext';
import { Sidebar } from './Sidebar';
import { Toolbar } from './Toolbar';
import { DetailInspector } from './DetailInspector';
import { TodayView } from './views/TodayView';
import { InboxView } from './views/InboxView';
import { KanbanView } from './views/KanbanView';
import { CalendarView } from './views/CalendarView';
import { ProjectDetailView } from './views/ProjectDetailView';
import { CompletedView } from './views/CompletedView';
import { SettingsView } from './views/SettingsView';

export function MacOSWindow() {
  const { state } = useApp();

  const renderView = () => {
    switch (state.selectedView) {
      case 'today': return <TodayView />;
      case 'inbox': return <InboxView />;
      case 'kanban': return <KanbanView />;
      case 'calendar': return <CalendarView />;
      case 'project_detail': return <ProjectDetailView />;
      case 'completed': return <CompletedView />;
      case 'settings': return <SettingsView />;
      default: return <TodayView />;
    }
  };

  return (
    <div className={`w-full h-full flex flex-col rounded-[10px] overflow-hidden shadow-2xl border border-border/50 ${
      state.theme === 'dark' ? 'bg-[#1C1C1E]' : 'bg-white'
    }`}>
      {/* Title Bar */}
      <div className={`h-[28px] flex items-center px-4 flex-shrink-0 ${
        state.theme === 'dark' ? 'bg-[#2C2C2E]' : 'bg-[#F2F2F7]'
      }`}>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#FF5F57]" />
          <div className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
          <div className="w-3 h-3 rounded-full bg-[#28C840]" />
        </div>
        <span className="absolute left-1/2 -translate-x-1/2 text-[11px] text-muted-foreground font-medium">
          Focus
        </span>
      </div>

      {/* Toolbar */}
      <Toolbar />

      {/* Content */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />

        <div className="flex-1 flex min-w-0">
          {/* Main Content */}
          <div className="flex-1 overflow-y-auto hide-scrollbar bg-background">
            <AnimatePresence mode="wait">
              {renderView()}
            </AnimatePresence>
          </div>

          {/* Detail Inspector */}
          {state.detailVisible && (
            <DetailInspector />
          )}
        </div>
      </div>
    </div>
  );
}
