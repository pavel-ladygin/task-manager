import { format, parseISO } from 'date-fns';
import { Clock, Calendar, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { TaskStatus, Priority } from '@/types';
import { useApp } from '@/hooks/useAppContext';
import { StatusPill } from '@/components/shared/StatusPill';
import { PriorityIndicator } from '@/components/shared/PriorityIndicator';
import { Checkbox } from '@/components/shared/Checkbox';

export function DetailInspector() {
  const { state, dispatch } = useApp();
  const task = state.selectedTaskId ? state.tasks.find(t => t.id === state.selectedTaskId) : null;

  if (!task) {
    return (
      <div className="w-[340px] border-l border-border bg-background flex flex-col items-center justify-center flex-shrink-0">
        <FileText size={48} className="text-muted-foreground/20 mb-3" strokeWidth={1} />
        <p className="text-sm text-muted-foreground">Select a task to view details</p>
      </div>
    );
  }

  const project = task.projectId ? state.projects.find(p => p.id === task.projectId) : null;
  const checklistTotal = task.checklist.length;
  const checklistDone = task.checklist.filter(c => c.completed).length;

  const updateTask = (updates: Partial<typeof task>) => {
    dispatch({ type: 'UPDATE_TASK', taskId: task.id, updates });
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={task.id}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 20 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="w-[340px] border-l border-border bg-background flex flex-col flex-shrink-0 overflow-y-auto hide-scrollbar"
      >
        <div className="p-5 space-y-5">
          {/* Title */}
          <input
            type="text"
            value={task.title}
            onChange={(e) => updateTask({ title: e.target.value })}
            className="w-full text-[17px] font-semibold bg-transparent outline-none border-b border-transparent focus:border-border pb-1 transition-colors text-foreground placeholder:text-muted-foreground"
          />

          {/* Status */}
          <div className="space-y-2">
            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Status</label>
            <div className="flex flex-wrap gap-1.5">
              {(['inbox', 'planned', 'in_progress', 'done', 'cancelled'] as TaskStatus[]).map(s => (
                <StatusPill
                  key={s}
                  status={s}
                  active={task.status === s}
                  onClick={() => updateTask({ status: s })}
                />
              ))}
            </div>
          </div>

          {/* Priority */}
          <div className="space-y-2">
            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Priority</label>
            <div className="flex gap-1.5">
              {(['none', 'low', 'medium', 'high', 'urgent'] as Priority[]).map(p => (
                <button
                  key={p}
                  onClick={() => updateTask({ priority: p })}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
                    task.priority === p ? 'bg-secondary' : 'hover:bg-secondary/50'
                  }`}
                >
                  <PriorityIndicator priority={p} variant="flag" />
                </button>
              ))}
            </div>
          </div>

          {/* Project */}
          <div className="space-y-2">
            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Project</label>
            <button className="flex items-center gap-2 h-8 px-3 rounded-lg bg-secondary text-[13px] hover:bg-secondary/80 transition-colors w-full">
              {project ? (
                <>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: project.color }} />
                  <span className="text-foreground">{project.name}</span>
                </>
              ) : (
                <span className="text-muted-foreground">No project</span>
              )}
            </button>
          </div>

          {/* Dates */}
          <div className="space-y-2">
            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Dates</label>
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-[13px]">
                <Clock size={16} className="text-muted-foreground flex-shrink-0" />
                <span className="text-muted-foreground w-16">Scheduled</span>
                {task.scheduledDate ? (
                  <span className="text-foreground">
                    {format(parseISO(task.scheduledDate), 'MMM d, yyyy HH:mm')}
                  </span>
                ) : (
                  <span className="text-muted-foreground/50">Not set</span>
                )}
              </div>
              <div className="flex items-center gap-2 text-[13px]">
                <Calendar size={16} className="text-muted-foreground flex-shrink-0" />
                <span className="text-muted-foreground w-16">Due</span>
                {task.dueDate ? (
                  <span className="text-foreground">
                    {format(parseISO(task.dueDate), 'MMM d, yyyy HH:mm')}
                  </span>
                ) : (
                  <span className="text-muted-foreground/50">Not set</span>
                )}
              </div>
            </div>
          </div>

          {/* Checklist */}
          {checklistTotal > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Checklist</label>
                <span className="text-[11px] text-muted-foreground">{checklistDone}/{checklistTotal}</span>
              </div>
              <div className="space-y-0.5">
                {task.checklist.map(item => (
                  <div key={item.id} className="flex items-center gap-2 h-8 px-2 rounded hover:bg-secondary/30 transition-colors">
                    <Checkbox
                      checked={item.completed}
                      onToggle={() => {
                        updateTask({
                          checklist: task.checklist.map(c =>
                            c.id === item.id ? { ...c, completed: !c.completed } : c
                          )
                        });
                      }}
                      size={16}
                    />
                    <span className={`text-[13px] flex-1 ${item.completed ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
                      {item.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          <div className="space-y-2">
            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Notes</label>
            <textarea
              value={task.notes}
              onChange={(e) => updateTask({ notes: e.target.value })}
              placeholder="Add notes..."
              className="w-full min-h-[80px] p-3 rounded-xl bg-secondary/50 text-[13px] outline-none resize-none text-foreground placeholder:text-muted-foreground border border-transparent focus:border-border transition-colors"
            />
          </div>

          {/* Metadata */}
          <div className="pt-3 border-t border-border">
            <p className="text-[11px] text-muted-foreground">
              Created {format(parseISO(task.createdAt), 'MMM d, yyyy')}
              {task.updatedAt !== task.createdAt && ` · Updated ${format(parseISO(task.updatedAt), 'MMM d, yyyy')}`}
              {task.completedAt && ` · Completed ${format(parseISO(task.completedAt), 'MMM d, yyyy')}`}
            </p>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
