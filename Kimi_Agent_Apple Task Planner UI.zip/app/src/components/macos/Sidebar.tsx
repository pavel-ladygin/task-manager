import { motion } from 'framer-motion';
import {
  Sun,
  Inbox,
  Calendar,
  LayoutTemplate,
  CalendarDays,
  CheckCircle,
  Settings,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { isPast, isToday, parseISO } from 'date-fns';
import type { MacOSView, Task } from '@/types';
import { useApp } from '@/hooks/useAppContext';
import { cn } from '@/lib/utils';

interface NavItem {
  view: MacOSView;
  label: string;
  icon: React.ElementType;
  badge?: number;
  divider?: boolean;
}

function getTaskCountForView(view: MacOSView, tasks: Task[]): number {
  switch (view) {
    case 'today':
      return tasks.filter(t =>
        (t.dueDate && (isToday(parseISO(t.dueDate)) || isPast(parseISO(t.dueDate)))) ||
        (t.scheduledDate && isToday(parseISO(t.scheduledDate)))
      ).length;
    case 'inbox':
      return tasks.filter(t => t.status === 'inbox').length;
    case 'upcoming':
      return tasks.filter(t =>
        (t.scheduledDate && !isToday(parseISO(t.scheduledDate))) ||
        (t.dueDate && !isToday(parseISO(t.dueDate)) && !isPast(parseISO(t.dueDate)))
      ).length;
    case 'completed':
      return tasks.filter(t => t.status === 'done').length;
    default:
      return 0;
  }
}

const navItems: NavItem[] = [
  { view: 'today', label: 'Today', icon: Sun },
  { view: 'inbox', label: 'Inbox', icon: Inbox, badge: 3 },
  { view: 'upcoming', label: 'Upcoming', icon: Calendar, badge: 8 },
  { view: 'kanban', label: 'Kanban', icon: LayoutTemplate },
  { view: 'calendar', label: 'Calendar', icon: CalendarDays },
  { view: 'completed', label: 'Completed', icon: CheckCircle, badge: 12, divider: true },
  { view: 'settings', label: 'Settings', icon: Settings },
];

export function Sidebar() {
  const { state, dispatch } = useApp();
  const collapsed = state.sidebarCollapsed;
  const currentView = state.selectedView;

  return (
    <motion.div
      animate={{ width: collapsed ? 72 : 220 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="h-full flex flex-col glass-panel relative z-20"
    >
      {/* App Header */}
      <div className="flex items-center h-[44px] px-3 gap-2 flex-shrink-0">
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex items-center gap-2"
          >
            <div
              className="w-6 h-6 rounded-md flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #4F5BD5, #8B5CF6)' }}
            >
              <CheckCircle size={14} className="text-white" />
            </div>
            <span className="text-[13px] font-semibold text-foreground">Focus</span>
          </motion.div>
        )}
        <button
          onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
          className="ml-auto p-1 rounded hover:bg-secondary/50 transition-colors"
        >
          {collapsed ? <PanelLeftOpen size={16} className="text-muted-foreground" /> : <PanelLeftClose size={16} className="text-muted-foreground" />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-2 space-y-0.5 overflow-y-auto hide-scrollbar">
        {navItems.map((item) => (
          <div key={item.view}>
            {item.divider && <div className="my-2 mx-2 h-px bg-border" />}
            <SidebarItem
              item={item}
              active={currentView === item.view}
              collapsed={collapsed}
              badge={getTaskCountForView(item.view, state.tasks)}
              onClick={() => dispatch({ type: 'SELECT_VIEW', view: item.view })}
            />
          </div>
        ))}

        {/* Projects Section */}
        {!collapsed && (
          <div className="mt-3">
            <div className="px-3 py-1">
              <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">Projects</span>
            </div>
            {state.projects.filter(p => p.status === 'active').map(project => (
              <button
                key={project.id}
                onClick={() => dispatch({ type: 'SELECT_PROJECT', projectId: project.id })}
                className={cn(
                  'w-full flex items-center h-8 px-3 rounded-lg text-[13px] transition-colors duration-150',
                  state.selectedView === 'project_detail' && state.selectedProjectId === project.id
                    ? 'font-medium'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                )}
                style={
                  state.selectedView === 'project_detail' && state.selectedProjectId === project.id
                    ? { backgroundColor: `${project.color}15`, color: project.color }
                    : {}
                }
              >
                <span
                  className="w-2 h-2 rounded-full mr-2.5 flex-shrink-0"
                  style={{ backgroundColor: project.color }}
                />
                <span className="truncate text-left flex-1">{project.name}</span>
                <span className="text-[10px] text-muted-foreground ml-1">
                  {state.tasks.filter(t => t.projectId === project.id && t.status !== 'done').length}
                </span>
              </button>
            ))}
          </div>
        )}
      </nav>
    </motion.div>
  );
}

function SidebarItem({ item, active, collapsed, badge, onClick }: {
  item: NavItem;
  active: boolean;
  collapsed: boolean;
  badge: number;
  onClick: () => void;
}) {
  const Icon = item.icon;

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full flex items-center rounded-lg transition-all duration-150 cursor-pointer',
        collapsed ? 'justify-center h-9 px-2' : 'h-8 px-3 gap-2.5',
        active
          ? 'font-medium'
          : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
      )}
      style={
        active
          ? { backgroundColor: 'var(--accent-color)', color: '#fff', opacity: 0.9 }
          : {}
      }
    >
      <Icon size={collapsed ? 20 : 16} strokeWidth={active ? 2 : 1.5} />
      {!collapsed && (
        <>
          <span className="text-[13px] flex-1 text-left truncate">{item.label}</span>
          {badge > 0 && (
            <span className={`text-[11px] tabular-nums ${active ? 'text-white/70' : 'text-muted-foreground'}`}>
              {badge}
            </span>
          )}
        </>
      )}
    </button>
  );
}
