import { motion } from 'framer-motion';
import { format, parseISO } from 'date-fns';
import { Calendar, CheckCircle } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { TaskRow } from '@/components/shared/TaskRow';
import { SectionHeader } from '@/components/shared/SectionHeader';
import { QuickAddField } from '@/components/shared/QuickAddField';
import { EmptyState } from '@/components/shared/EmptyState';

export function ProjectDetailView() {
  const { state, dispatch } = useApp();
  const project = state.selectedProjectId
    ? state.projects.find(p => p.id === state.selectedProjectId)
    : null;

  if (!project) {
    return (
      <div className="flex items-center justify-center h-full">
        <EmptyState
          icon={CheckCircle}
          title="No project selected"
          subtitle="Select a project from the sidebar"
        />
      </div>
    );
  }

  const projectTasks = state.tasks.filter(t => t.projectId === project.id);
  const activeTasks = projectTasks.filter(t => t.status !== 'done' && t.status !== 'cancelled');
  const completedTasks = projectTasks.filter(t => t.status === 'done');
  const progress = projectTasks.length > 0 ? (completedTasks.length / projectTasks.length) * 100 : 0;

  return (
    <motion.div
      key={`project-${project.id}`}
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
    >
      {/* Project Header */}
      <div className="px-6 pt-6 pb-4">
        {/* Color bar */}
        <div className="h-1 rounded-full mb-4" style={{ backgroundColor: project.color }} />

        <div className="flex items-center gap-3 mb-3">
          <span className="w-4 h-4 rounded-full" style={{ backgroundColor: project.color }} />
          <h2 className="text-[22px] font-semibold text-foreground">{project.name}</h2>
        </div>

        <div className="flex items-center gap-4 mb-4">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium text-white" style={{ backgroundColor: 'var(--accent-color)' }}>
            {project.status === 'active' ? 'Active' : 'Archived'}
          </span>
          {project.deadline && (
            <span className="flex items-center gap-1 text-[12px] text-muted-foreground">
              <Calendar size={12} />
              Due {format(parseISO(project.deadline), 'MMM d, yyyy')}
            </span>
          )}
          <span className="text-[12px] text-muted-foreground">
            {completedTasks.length} of {projectTasks.length} tasks completed
          </span>
        </div>

        {/* Progress bar */}
        <div className="h-1.5 bg-secondary rounded-full overflow-hidden mb-3">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="h-full rounded-full"
            style={{ backgroundColor: project.color }}
          />
        </div>

        {/* Notes */}
        <p className="text-[13px] text-muted-foreground">{project.notes}</p>
      </div>

      {/* Task List */}
      <div className="py-2">
        {/* Active */}
        {activeTasks.length > 0 && (
          <div>
            <SectionHeader title="Active" count={activeTasks.length} />
            {activeTasks.map(task => (
              <TaskRow
                key={task.id}
                task={task}
                selected={state.selectedTaskId === task.id}
                onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
              />
            ))}
          </div>
        )}

        {/* Completed */}
        {completedTasks.length > 0 && (
          <div>
            <SectionHeader title="Completed" count={completedTasks.length} defaultCollapsed />
          </div>
        )}
      </div>

      <div className="px-4 pt-2 pb-4">
        <QuickAddField projectId={project.id} />
      </div>
    </motion.div>
  );
}
