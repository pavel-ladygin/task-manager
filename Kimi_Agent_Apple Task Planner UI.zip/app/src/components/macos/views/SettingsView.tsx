import { motion } from 'framer-motion';
import { CheckCircle, Sun, Moon, Monitor, Upload, Download, Trash2 } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';

export function SettingsView() {
  const { state, dispatch } = useApp();

  const handleTheme = (theme: 'light' | 'dark') => {
    dispatch({ type: 'SET_THEME', theme });
  };

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="mb-8">
      <h3 className="text-[15px] font-medium text-foreground mb-3 px-6">{title}</h3>
      <div className="mx-6 rounded-xl bg-secondary/40 divide-y divide-border/50 overflow-hidden">
        {children}
      </div>
    </div>
  );

  const Row = ({ label, children, icon: Icon }: { label: string; children?: React.ReactNode; icon?: React.ElementType }) => (
    <div className="flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-3">
        {Icon && <Icon size={16} className="text-muted-foreground" />}
        <span className="text-[13px] text-foreground">{label}</span>
      </div>
      {children}
    </div>
  );

  const Toggle = ({ checked, onChange }: { checked: boolean; onChange: () => void }) => (
    <button
      onClick={onChange}
      className={`relative w-10 h-6 rounded-full transition-colors duration-200 ${
        checked ? '' : 'bg-muted'
      }`}
      style={checked ? { backgroundColor: 'var(--accent-color)' } : {}}
    >
      <div
        className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-200 ${
          checked ? 'translate-x-[18px]' : 'translate-x-0.5'
        }`}
      />
    </button>
  );

  return (
    <motion.div
      key="settings"
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
      className="py-6 max-w-[600px] mx-auto"
    >
      {/* App Icon */}
      <div className="flex flex-col items-center mb-8">
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center mb-3 shadow-lg"
          style={{ background: 'linear-gradient(135deg, #4F5BD5, #8B5CF6)' }}
        >
          <CheckCircle size={32} className="text-white" />
        </div>
        <h2 className="text-[17px] font-semibold text-foreground">Focus</h2>
        <p className="text-[12px] text-muted-foreground">Version 1.0</p>
      </div>

      {/* General */}
      <Section title="General">
        <Row label="Appearance" icon={Monitor}>
          <div className="flex bg-secondary rounded-lg p-0.5">
            {([
              { key: 'light', icon: Sun, label: 'Light' },
              { key: 'dark', icon: Moon, label: 'Dark' },
            ] as const).map(({ key, icon: I }) => (
              <button
                key={key}
                onClick={() => handleTheme(key)}
                className={`flex items-center gap-1 px-3 py-1 rounded-md text-[12px] transition-colors ${
                  state.theme === key
                    ? 'text-white'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                style={state.theme === key ? { backgroundColor: 'var(--accent-color)' } : {}}
              >
                <I size={12} />
                {key.charAt(0).toUpperCase() + key.slice(1)}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Default View">
          <span className="text-[13px] text-muted-foreground">Today</span>
        </Row>
        <Row label="Week Starts On">
          <span className="text-[13px] text-muted-foreground">Monday</span>
        </Row>
        <Row label="Time Format">
          <span className="text-[13px] text-muted-foreground">24-hour</span>
        </Row>
      </Section>

      {/* Notifications */}
      <Section title="Notifications">
        <Row label="Enable Notifications">
          <Toggle checked={true} onChange={() => {}} />
        </Row>
        <Row label="Daily Summary">
          <Toggle checked={true} onChange={() => {}} />
        </Row>
      </Section>

      {/* Data */}
      <Section title="Data">
        <Row label="Export Tasks" icon={Upload}>
          <button className="text-[13px]" style={{ color: 'var(--accent-color)' }}>Export</button>
        </Row>
        <Row label="Import Tasks" icon={Download}>
          <button className="text-[13px]" style={{ color: 'var(--accent-color)' }}>Import</button>
        </Row>
        <Row label="Delete All Completed" icon={Trash2}>
          <button className="text-[13px] text-[var(--overdue)]">Delete</button>
        </Row>
      </Section>

      {/* About */}
      <Section title="About">
        <Row label="Send Feedback" />
        <Row label="Privacy Policy" />
        <Row label="Terms of Service" />
      </Section>
    </motion.div>
  );
}
