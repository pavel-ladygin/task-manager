import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { TaskRow } from '@/components/shared/TaskRow';
import { EmptyState } from '@/components/shared/EmptyState';

export function CompletedView() {
  const { state, dispatch } = useApp();
  const completedTasks = state.tasks.filter(t => t.status === 'done');

  return (
    <motion.div
      key="completed"
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
      className="py-2"
    >
      {completedTasks.length === 0 ? (
        <EmptyState
          icon={CheckCircle}
          title="No completed tasks"
          subtitle="Tasks you complete will appear here"
        />
      ) : (
        completedTasks.map(task => (
          <TaskRow
            key={task.id}
            task={task}
            selected={state.selectedTaskId === task.id}
            onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
          />
        ))
      )}
    </motion.div>
  );
}
