import { useMemo } from 'react';
import { format, startOfWeek, addDays, parseISO, isToday, isSameDay } from 'date-fns';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const SLOT_HEIGHT = 40; // pixels per 30-min slot

export function CalendarView() {
  const { state, dispatch } = useApp();

  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 }); // Monday
  const weekDays = useMemo(() =>
    Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)),
    [weekStart]
  );


  // All-day / due tasks (tasks without specific time)
  const allDayTasks = state.tasks.filter(t => {
    if (!t.scheduledDate && !t.dueDate) return false;
    const date = t.scheduledDate ? parseISO(t.scheduledDate) : t.dueDate ? parseISO(t.dueDate) : null;
    if (!date) return false;
    return weekDays.some(d => isSameDay(d, date));
  });

  // Timed tasks
  const timedTasks = state.tasks.filter(t => {
    if (!t.scheduledDate) return false;
    const date = parseISO(t.scheduledDate);
    return weekDays.some(d => isSameDay(d, date));
  });

  return (
    <motion.div
      key="calendar"
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
      className="h-full flex flex-col"
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-border flex-shrink-0">
        <div className="flex items-center gap-1">
          <button className="p-1 rounded hover:bg-secondary transition-colors">
            <ChevronLeft size={18} className="text-muted-foreground" />
          </button>
          <button className="p-1 rounded hover:bg-secondary transition-colors">
            <ChevronRight size={18} className="text-muted-foreground" />
          </button>
        </div>
        <span className="text-[15px] font-semibold text-foreground">
          {format(weekStart, 'MMM d')} – {format(addDays(weekStart, 6), 'MMM d, yyyy')}
        </span>
        <button
          className="px-3 py-1 rounded-lg text-xs font-medium text-white"
          style={{ backgroundColor: 'var(--accent-color)' }}
        >
          Today
        </button>
      </div>

      {/* All-day Row */}
      <div className="flex border-b border-border flex-shrink-0" style={{ minHeight: 40 }}>
        <div className="w-14 flex-shrink-0 border-r border-border" />
        <div className="flex-1 grid grid-cols-7">
          {weekDays.map((day, idx) => {
            const dayTasks = allDayTasks.filter(t => {
              const d = t.scheduledDate ? parseISO(t.scheduledDate) : t.dueDate ? parseISO(t.dueDate) : null;
              return d && isSameDay(d, day);
            });
            return (
              <div key={idx} className={`border-r border-border last:border-r-0 p-1 space-y-0.5 ${isToday(day) ? 'bg-[var(--accent-color)]/[0.03]' : ''}`}>
                {dayTasks.map(task => {
                  const project = task.projectId ? state.projects.find(p => p.id === task.projectId) : null;
                  const isOverdue = task.dueDate && parseISO(task.dueDate) < new Date() && !isToday(parseISO(task.dueDate)) && task.status !== 'done';
                  return (
                    <div
                      key={task.id}
                      onClick={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
                      className="px-1.5 py-0.5 rounded text-[11px] truncate cursor-pointer hover:brightness-95 transition-all"
                      style={{
                        backgroundColor: project ? `${project.color}20` : 'hsl(var(--secondary))',
                        borderLeft: `3px solid ${isOverdue ? 'var(--overdue)' : project ? project.color : 'transparent'}`,
                      }}
                    >
                      {task.title}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>

      {/* Time Grid */}
      <div className="flex-1 overflow-y-auto hide-scrollbar relative">
        <div className="flex">
          {/* Time Labels */}
          <div className="w-14 flex-shrink-0 border-r border-border">
            {HOURS.map(hour => (
              <div key={hour} className="text-right pr-2 text-[11px] text-muted-foreground" style={{ height: SLOT_HEIGHT }}>
                {String(hour).padStart(2, '0')}:00
              </div>
            ))}
          </div>

          {/* Day Columns */}
          <div className="flex-1 grid grid-cols-7 relative">
            {/* Grid Lines */}
            {HOURS.map(hour => (
              <div
                key={hour}
                className="absolute left-0 right-0 border-b border-border/50 pointer-events-none"
                style={{ top: hour * SLOT_HEIGHT }}
              />
            ))}

            {/* Day Columns */}
            {weekDays.map((day, dayIdx) => (
              <div
                key={dayIdx}
                className={`relative border-r border-border last:border-r-0 ${isToday(day) ? 'bg-[var(--accent-color)]/[0.02]' : ''}`}
              >
                {/* Current time indicator */}
                {isToday(day) && (
                  <div
                    className="absolute left-0 right-0 z-10 pointer-events-none"
                    style={{
                      top: (new Date().getHours() + new Date().getMinutes() / 60) * SLOT_HEIGHT,
                    }}
                  >
                    <div className="flex items-center">
                      <div className="w-1.5 h-1.5 rounded-full -ml-[3px]" style={{ backgroundColor: 'var(--accent-color)' }} />
                      <div className="flex-1 h-[2px]" style={{ backgroundColor: 'var(--accent-color)' }} />
                    </div>
                  </div>
                )}

                {/* Task blocks */}
                {timedTasks.filter(t => {
                  const d = parseISO(t.scheduledDate!);
                  return isSameDay(d, day);
                }).map(task => {
                  const date = parseISO(task.scheduledDate!);
                  const hour = date.getHours();
                  const minute = date.getMinutes();
                  const top = (hour + minute / 60) * SLOT_HEIGHT;
                  const project = task.projectId ? state.projects.find(p => p.id === task.projectId) : null;
                  const bgColor = project ? project.color : 'var(--accent-color)';

                  return (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      onClick={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
                      className="absolute left-[5%] right-[5%] rounded-md px-2 py-1 cursor-pointer hover:brightness-110 transition-all overflow-hidden"
                      style={{
                        top: top + 2,
                        height: Math.max(SLOT_HEIGHT - 4, 28),
                        backgroundColor: bgColor,
                      }}
                    >
                      <p className="text-white text-[11px] font-medium truncate leading-tight">{task.title}</p>
                      <p className="text-white/80 text-[10px]">{format(date, 'HH:mm')}</p>
                    </motion.div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
