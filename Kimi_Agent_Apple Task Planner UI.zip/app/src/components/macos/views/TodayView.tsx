import { isPast, isToday, parseISO, isFuture } from 'date-fns';
import { motion } from 'framer-motion';
import { Sun } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { TaskRow } from '@/components/shared/TaskRow';
import { SectionHeader } from '@/components/shared/SectionHeader';
import { QuickAddField } from '@/components/shared/QuickAddField';
import { EmptyState } from '@/components/shared/EmptyState';

export function TodayView() {
  const { state, dispatch } = useApp();

  const overdue = state.tasks.filter(t =>
    t.dueDate && isPast(parseISO(t.dueDate)) && !isToday(parseISO(t.dueDate)) && t.status !== 'done' && t.status !== 'cancelled'
  );
  const todayTasks = state.tasks.filter(t =>
    (t.scheduledDate && isToday(parseISO(t.scheduledDate)) && t.status !== 'done' && t.status !== 'cancelled') ||
    (t.dueDate && isToday(parseISO(t.dueDate)) && t.status !== 'done' && t.status !== 'cancelled')
  );
  const later = state.tasks.filter(t =>
    ((t.scheduledDate && isFuture(parseISO(t.scheduledDate)) && !isToday(parseISO(t.scheduledDate))) ||
    (t.dueDate && isFuture(parseISO(t.dueDate)) && !isToday(parseISO(t.dueDate)))) &&
    t.status !== 'done' && t.status !== 'cancelled' && !overdue.includes(t)
  );
  const completed = state.tasks.filter(t => t.status === 'done');

  return (
    <motion.div
      key="today"
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
      className="py-2"
    >
      {/* Overdue */}
      {overdue.length > 0 && (
        <div>
          <SectionHeader title="Overdue" count={overdue.length} overdueTint />
          {overdue.map(task => (
            <TaskRow
              key={task.id}
              task={task}
              selected={state.selectedTaskId === task.id}
              onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
            />
          ))}
        </div>
      )}

      {/* Today */}
      {todayTasks.length > 0 ? (
        <div>
          <SectionHeader title="Today" count={todayTasks.length} />
          {todayTasks.map(task => (
            <TaskRow
              key={task.id}
              task={task}
              selected={state.selectedTaskId === task.id}
              onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
            />
          ))}
        </div>
      ) : (
        overdue.length === 0 && (
          <EmptyState
            icon={Sun}
            title="You're all caught up"
            subtitle="No tasks scheduled for today"
          />
        )
      )}

      {/* Later */}
      {later.length > 0 && (
        <div>
          <SectionHeader title="Later" count={later.length} />
          {later.map(task => (
            <TaskRow
              key={task.id}
              task={task}
              selected={state.selectedTaskId === task.id}
              onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
            />
          ))}
        </div>
      )}

      {/* Completed */}
      {completed.length > 0 && (
        <div>
          <SectionHeader title="Completed" count={completed.length} defaultCollapsed />
          {!false && completed.slice(0, 3).map(task => (
            <TaskRow
              key={task.id}
              task={task}
              selected={state.selectedTaskId === task.id}
              onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
            />
          ))}
        </div>
      )}

      {/* Quick Add */}
      <div className="px-4 pt-3 pb-4">
        <QuickAddField />
      </div>
    </motion.div>
  );
}
