import { motion } from 'framer-motion';
import { Inbox, Calendar, PlayCircle, CheckCircle, XCircle } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { EmptyState } from '@/components/shared/EmptyState';
import type { TaskStatus } from '@/types';

const columns: { status: TaskStatus; label: string; icon: any }[] = [
  { status: 'inbox', label: 'Inbox', icon: Inbox },
  { status: 'planned', label: 'Planned', icon: Calendar },
  { status: 'in_progress', label: 'In Progress', icon: PlayCircle },
  { status: 'done', label: 'Done', icon: CheckCircle },
  { status: 'cancelled', label: 'Cancelled', icon: XCircle },
];

export function KanbanView() {
  const { state, dispatch } = useApp();

  return (
    <motion.div
      key="kanban"
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
      className="h-full overflow-x-auto hide-scrollbar"
    >
      <div className="flex h-full gap-3 p-3 min-w-fit">
        {columns.map(col => {
          const colTasks = state.tasks.filter(t => t.status === col.status);
          const Icon = col.icon;

          return (
            <div
              key={col.status}
              className="w-[280px] flex-shrink-0 flex flex-col rounded-xl bg-secondary/40 overflow-hidden"
            >
              {/* Column Header */}
              <div className="flex items-center gap-2 px-3 pt-3 pb-2">
                <Icon size={18} className="text-muted-foreground" />
                <span className="text-[14px] font-semibold text-foreground">{col.label}</span>
                <span className="text-[11px] text-muted-foreground ml-auto">{colTasks.length}</span>
              </div>

              {/* Cards */}
              <div className="flex-1 overflow-y-auto hide-scrollbar px-2 pb-2 space-y-2">
                {colTasks.length === 0 ? (
                  <div className="py-8">
                    <EmptyState
                      icon={Icon}
                      title="No tasks"
                      subtitle={`No tasks in ${col.label.toLowerCase()}`}
                    />
                  </div>
                ) : (
                  colTasks.map((task, i) => {
                    const project = task.projectId ? state.projects.find(p => p.id === task.projectId) : null;
                    return (
                      <motion.div
                        key={task.id}
                        layout
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.03, duration: 0.25 }}
                        onClick={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
                        className="bg-background rounded-xl p-3 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer border border-border/30"
                      >
                        {/* Top row: project + priority */}
                        <div className="flex items-center justify-between mb-1.5">
                          {project && (
                            <span
                              className="text-[11px] font-medium px-1.5 py-0.5 rounded-full"
                              style={{
                                backgroundColor: `${project.color}18`,
                                color: project.color,
                              }}
                            >
                              {project.name}
                            </span>
                          )}
                          {task.priority !== 'none' && (
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{
                                backgroundColor: task.priority === 'urgent' || task.priority === 'high'
                                  ? 'var(--overdue)'
                                  : task.priority === 'medium'
                                  ? 'var(--warning)'
                                  : 'var(--completed)',
                              }}
                            />
                          )}
                        </div>

                        {/* Title */}
                        <p className={`text-[13px] font-medium leading-snug ${task.status === 'done' ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
                          {task.title}
                        </p>

                        {/* Date row */}
                        <div className="flex items-center gap-2 mt-1.5 text-[11px] text-muted-foreground">
                          {task.scheduledDate && (
                            <span>{new Date(task.scheduledDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          )}
                          {task.dueDate && (
                            <span style={{
                              color: new Date(task.dueDate) < new Date() && task.status !== 'done' ? 'var(--overdue)' : undefined
                            }}>
                              Due {new Date(task.dueDate).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                            </span>
                          )}
                        </div>

                        {/* Checklist indicator */}
                        {task.checklist.length > 0 && (
                          <div className="flex items-center gap-1 mt-1.5 text-[10px] text-muted-foreground">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>
                            </svg>
                            {task.checklist.filter(c => c.completed).length}/{task.checklist.length}
                          </div>
                        )}
                      </motion.div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
