import { motion } from 'framer-motion';
import { Inbox, Calendar, Flag, FolderPlus } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { TaskRow } from '@/components/shared/TaskRow';
import { QuickAddField } from '@/components/shared/QuickAddField';
import { EmptyState } from '@/components/shared/EmptyState';

export function InboxView() {
  const { state, dispatch } = useApp();
  const inboxTasks = state.tasks.filter(t => t.status === 'inbox');

  return (
    <motion.div
      key="inbox"
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.25 }}
      className="py-2"
    >
      {inboxTasks.length === 0 ? (
        <EmptyState
          icon={Inbox}
          title="Inbox Zero"
          subtitle="All tasks have been processed"
        />
      ) : (
        <>
          <div className="px-4 pt-2 pb-3">
            <QuickAddField />
          </div>
          {inboxTasks.map(task => (
            <div key={task.id} className="group relative">
              <TaskRow
                task={task}
                selected={state.selectedTaskId === task.id}
                onSelect={() => dispatch({ type: 'SELECT_TASK', taskId: task.id })}
                hideProject
              />
              {/* Hover triage actions */}
              <div className="absolute right-2 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-0.5 bg-background/90 backdrop-blur-sm rounded-lg p-0.5">
                <button className="p-1 rounded hover:bg-secondary transition-colors" title="Assign project">
                  <FolderPlus size={14} className="text-muted-foreground" />
                </button>
                <button className="p-1 rounded hover:bg-secondary transition-colors" title="Schedule">
                  <Calendar size={14} className="text-muted-foreground" />
                </button>
                <button className="p-1 rounded hover:bg-secondary transition-colors" title="Priority">
                  <Flag size={14} className="text-muted-foreground" />
                </button>
              </div>
            </div>
          ))}
        </>
      )}
    </motion.div>
  );
}
