import { useState } from 'react';
import { Search, ArrowUpDown, SlidersHorizontal, Plus, Sidebar } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';

const viewTitles: Record<string, string> = {
  today: 'Today',
  inbox: 'Inbox',
  kanban: 'Kanban',
  calendar: 'Calendar',
  project_detail: 'Project',
  completed: 'Completed',
  settings: 'Settings',
};

export function Toolbar() {
  const { state, dispatch } = useApp();
  const [searchFocused, setSearchFocused] = useState(false);

  const viewTitle = state.selectedView === 'project_detail' && state.selectedProjectId
    ? state.projects.find(p => p.id === state.selectedProjectId)?.name || 'Project'
    : viewTitles[state.selectedView] || 'Focus';

  const taskCount = state.tasks.filter(t => t.status !== 'done' && t.status !== 'cancelled').length;

  return (
    <div className="h-[44px] flex items-center px-4 glass-panel flex-shrink-0 relative z-10">
      {/* Left */}
      <div className="flex items-center gap-3 flex-1">
        <button
          onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
          className="p-1 rounded hover:bg-secondary/50 transition-colors"
        >
          <Sidebar size={18} className="text-muted-foreground" />
        </button>
        <span className="text-[13px] font-semibold text-foreground">{viewTitle}</span>
        <span className="text-[11px] text-muted-foreground">({taskCount})</span>
      </div>

      {/* Center - Search */}
      <div className="flex-1 flex justify-center">
        <div
          className={`flex items-center h-7 rounded-full bg-secondary transition-all duration-200 ${
            searchFocused ? 'w-[340px] bg-background shadow-sm border border-border' : 'w-[280px]'
          }`}
        >
          <Search size={14} className="ml-2.5 text-muted-foreground flex-shrink-0" />
          <input
            type="text"
            placeholder="Search tasks..."
            onFocus={() => setSearchFocused(true)}
            onBlur={() => setSearchFocused(false)}
            className="flex-1 bg-transparent text-[13px] outline-none ml-1.5 placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-1 flex-1 justify-end">
        <button className="p-1.5 rounded-lg hover:bg-secondary/50 transition-colors">
          <ArrowUpDown size={16} className="text-muted-foreground" />
        </button>
        <button className="p-1.5 rounded-lg hover:bg-secondary/50 transition-colors">
          <SlidersHorizontal size={16} className="text-muted-foreground" />
        </button>
        <button
          className="ml-1 w-8 h-8 rounded-full flex items-center justify-center text-white transition-transform hover:scale-105"
          style={{ backgroundColor: 'var(--accent-color)' }}
        >
          <Plus size={16} />
        </button>
      </div>
    </div>
  );
}
