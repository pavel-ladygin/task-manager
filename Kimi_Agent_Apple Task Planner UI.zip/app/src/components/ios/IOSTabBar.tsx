import { Sun, Inbox, Calendar, Folder, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import type { IOSTab } from '@/types';
import { useApp } from '@/hooks/useAppContext';

const tabs: { key: IOSTab; label: string; icon: React.ElementType }[] = [
  { key: 'today', label: 'Today', icon: Sun },
  { key: 'inbox', label: 'Inbox', icon: Inbox },
  { key: 'upcoming', label: 'Upcoming', icon: Calendar },
  { key: 'projects', label: 'Projects', icon: Folder },
  { key: 'settings', label: 'Settings', icon: Settings },
];

export function IOSTabBar() {
  const { state, dispatch } = useApp();

  return (
    <div className="glass-panel flex-shrink-0 z-40 relative">
      <div className="flex items-center justify-around h-[49px] pb-safe">
        {tabs.map(tab => {
          const isActive = state.iosTab === tab.key;
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => dispatch({ type: 'SET_IOS_TAB', tab: tab.key })}
              className="flex flex-col items-center justify-center gap-0.5 w-12 h-full"
            >
              <motion.div
                animate={{ scale: isActive ? 1.1 : 1 }}
                transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              >
                <Icon
                  size={22}
                  strokeWidth={isActive ? 2.5 : 1.5}
                  className={isActive ? '' : 'text-muted-foreground'}
                  style={isActive ? { color: 'var(--accent-color)' } : {}}
                />
              </motion.div>
              <span
                className={`text-[10px] ${isActive ? 'font-medium' : 'text-muted-foreground'}`}
                style={isActive ? { color: 'var(--accent-color)' } : {}}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
