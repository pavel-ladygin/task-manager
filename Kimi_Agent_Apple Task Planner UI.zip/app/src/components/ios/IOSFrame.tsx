import { useApp } from '@/hooks/useAppContext';
import { IOSTabBar } from './IOSTabBar';
import { IOSTodayScreen } from './screens/IOSTodayScreen';
import { IOSInboxScreen } from './screens/IOSInboxScreen';
import { IOSUpcomingScreen } from './screens/IOSUpcomingScreen';
import { IOSProjectsScreen } from './screens/IOSProjectsScreen';
import { IOSSettingsScreen } from './screens/IOSSettingsScreen';
import { IOSProjectDetailScreen } from './screens/IOSProjectDetailScreen';

export function IOSFrame() {
  const { state } = useApp();

  const renderScreen = () => {
    switch (state.iosScreen) {
      case 'today': return <IOSTodayScreen />;
      case 'inbox': return <IOSInboxScreen />;
      case 'upcoming': return <IOSUpcomingScreen />;
      case 'projects': return <IOSProjectsScreen />;
      case 'settings': return <IOSSettingsScreen />;
      case 'project_detail_ios': return <IOSProjectDetailScreen />;
      default: return <IOSTodayScreen />;
    }
  };

  return (
    <div className="flex flex-col items-center">
      <p className="text-[13px] text-muted-foreground mb-4 font-medium">iOS Companion</p>
      <div className="relative" style={{ width: 390, height: 844 }}>
        {/* Phone Frame */}
        <div className={`absolute inset-0 rounded-[55px] border-[8px] shadow-2xl overflow-hidden ${
          state.theme === 'dark' ? 'border-[#1a1a1a] bg-[#1C1C1E]' : 'border-[#2a2a2a] bg-background'
        }`}>
          {/* Dynamic Island */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-[120px] h-[35px] bg-black rounded-full z-50" />

          {/* Screen Content */}
          <div className="h-full flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto hide-scrollbar pt-12 pb-2">
              {renderScreen()}
            </div>

            {/* Tab Bar */}
            <IOSTabBar />
          </div>

          {/* Home Indicator */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-[134px] h-[5px] bg-foreground/20 rounded-full z-50" />
        </div>
      </div>
    </div>
  );
}
