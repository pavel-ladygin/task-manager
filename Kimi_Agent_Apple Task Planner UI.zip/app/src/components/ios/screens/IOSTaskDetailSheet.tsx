import { motion } from 'framer-motion';
import { format, parseISO } from 'date-fns';
import { Clock, Calendar, Folder, CheckSquare, FileText } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { Checkbox } from '@/components/shared/Checkbox';
import { StatusPill } from '@/components/shared/StatusPill';
import { PriorityIndicator } from '@/components/shared/PriorityIndicator';
import type { TaskStatus, Priority } from '@/types';

export function IOSTaskDetailSheet() {
  const { state, dispatch } = useApp();
  const task = state.iosSelectedTaskId ? state.tasks.find(t => t.id === state.iosSelectedTaskId) : null;

  if (!task) return null;

  const project = task.projectId ? state.projects.find(p => p.id === task.projectId) : null;
  const checklistTotal = task.checklist.length;
  const checklistDone = task.checklist.filter(c => c.completed).length;

  const close = () => dispatch({ type: 'SELECT_IOS_TASK', taskId: null });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-[60] flex flex-col justify-end"
    >
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={close}
        className="absolute inset-0 bg-black/30"
      />

      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: '5%' }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="relative bg-background rounded-t-3xl h-[95%] flex flex-col"
      >
        <div className="flex justify-center pt-2 pb-1">
          <div className="w-9 h-1 rounded-full bg-muted-foreground/30" />
        </div>

        <div className="flex items-center justify-between px-4 py-2 border-b border-border/50">
          <button onClick={close} className="text-[15px] text-muted-foreground">Cancel</button>
          <span className="text-[17px] font-semibold text-foreground">Task</span>
          <button onClick={close} className="text-[15px] font-medium" style={{ color: 'var(--accent-color)' }}>Save</button>
        </div>

        <div className="flex-1 overflow-y-auto hide-scrollbar p-4 space-y-5">
          <input
            type="text"
            defaultValue={task.title}
            className="w-full text-[22px] font-semibold bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
          />

          <div>
            <label className="text-[13px] font-medium text-muted-foreground mb-2 block">Status</label>
            <div className="flex flex-wrap gap-1.5">
              {(['inbox', 'planned', 'in_progress', 'done', 'cancelled'] as TaskStatus[]).map(s => (
                <StatusPill key={s} status={s} active={task.status === s} onClick={() => {}} />
              ))}
            </div>
          </div>

          <div>
            <label className="text-[13px] font-medium text-muted-foreground mb-2 block">Priority</label>
            <div className="flex gap-2">
              {(['none', 'low', 'medium', 'high', 'urgent'] as Priority[]).map(p => (
                <button key={p} className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <PriorityIndicator priority={p} variant="flag" />
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-border/50">
            <div className="flex items-center gap-2">
              <Folder size={18} className="text-muted-foreground" />
              <span className="text-[17px] text-foreground">Project</span>
            </div>
            <div className="flex items-center gap-2">
              {project ? (
                <>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: project.color }} />
                  <span className="text-[17px] text-muted-foreground">{project.name}</span>
                </>
              ) : (
                <span className="text-[17px] text-muted-foreground">None</span>
              )}
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between py-2 border-b border-border/50">
              <div className="flex items-center gap-2">
                <Clock size={18} className="text-muted-foreground" />
                <span className="text-[17px] text-foreground">Scheduled</span>
              </div>
              <span className="text-[17px] text-muted-foreground">
                {task.scheduledDate ? format(parseISO(task.scheduledDate), 'MMM d, HH:mm') : 'Not set'}
              </span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-border/50">
              <div className="flex items-center gap-2">
                <Calendar size={18} className="text-muted-foreground" />
                <span className="text-[17px] text-foreground">Due</span>
              </div>
              <span className="text-[17px] text-muted-foreground">
                {task.dueDate ? format(parseISO(task.dueDate), 'MMM d, HH:mm') : 'Not set'}
              </span>
            </div>
          </div>

          {checklistTotal > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <CheckSquare size={18} className="text-muted-foreground" />
                <span className="text-[17px] font-medium text-foreground">Checklist</span>
                <span className="text-[13px] text-muted-foreground">({checklistDone}/{checklistTotal})</span>
              </div>
              {task.checklist.map(item => (
                <div key={item.id} className="flex items-center gap-3 py-2">
                  <Checkbox checked={item.completed} onToggle={() => {}} size={20} />
                  <span className={`text-[17px] flex-1 ${item.completed ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
                    {item.text}
                  </span>
                </div>
              ))}
            </div>
          )}

          <div>
            <div className="flex items-center gap-2 mb-2">
              <FileText size={18} className="text-muted-foreground" />
              <span className="text-[17px] font-medium text-foreground">Notes</span>
            </div>
            <textarea
              defaultValue={task.notes}
              placeholder="Add notes..."
              className="w-full min-h-[100px] p-3 rounded-xl bg-secondary/50 text-[17px] outline-none resize-none text-foreground placeholder:text-muted-foreground"
            />
          </div>

          <p className="text-[12px] text-muted-foreground text-center pt-2">
            Created {format(parseISO(task.createdAt), 'MMM d, yyyy')}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}
