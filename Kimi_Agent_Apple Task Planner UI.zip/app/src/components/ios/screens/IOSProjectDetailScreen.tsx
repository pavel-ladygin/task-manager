import { useApp } from '@/hooks/useAppContext';
import { Checkbox } from '@/components/shared/Checkbox';
import { PriorityIndicator } from '@/components/shared/PriorityIndicator';
import { ChevronLeft } from 'lucide-react';

function IOSProjectTaskRow({ task }: { task: typeof import('@/data/mockData').tasks[0] }) {
  const { dispatch } = useApp();
  return (
    <div
      onClick={() => dispatch({ type: 'SELECT_IOS_TASK', taskId: task.id })}
      className="flex items-center gap-3 px-4 py-3 border-b border-border/50 cursor-pointer"
    >
      <Checkbox checked={task.status === 'done'} onToggle={() => dispatch({ type: 'TOGGLE_TASK_COMPLETE', taskId: task.id })} size={24} />
      <PriorityIndicator priority={task.priority} variant="dot" size={8} />
      <span className={`text-[17px] flex-1 ${task.status === 'done' ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
        {task.title}
      </span>
    </div>
  );
}

export function IOSProjectDetailScreen() {
  const { state, dispatch } = useApp();
  const project = state.iosSelectedProjectId
    ? state.projects.find(p => p.id === state.iosSelectedProjectId)
    : null;

  if (!project) return null;

  const projectTasks = state.tasks.filter(t => t.projectId === project.id);
  const activeTasks = projectTasks.filter(t => t.status !== 'done');
  const completedTasks = projectTasks.filter(t => t.status === 'done');
  const progress = projectTasks.length > 0 ? (completedTasks.length / projectTasks.length) * 100 : 0;

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-2 px-4 pt-2 pb-3">
        <button
          onClick={() => dispatch({ type: 'SELECT_IOS_PROJECT', projectId: null })}
          className="p-1 -ml-1"
        >
          <ChevronLeft size={24} className="text-[var(--accent-color)]" />
        </button>
        <h1 className="text-[22px] font-semibold text-foreground">{project.name}</h1>
      </div>

      <div className="px-4 pb-4">
        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${progress}%`, backgroundColor: project.color }}
          />
        </div>
        <p className="text-[13px] text-muted-foreground mt-1">
          {completedTasks.length} of {projectTasks.length} completed
        </p>
      </div>

      <div className="flex border-b border-border/50">
        <button className="flex-1 py-2 text-[15px] font-medium text-foreground border-b-2" style={{ borderColor: 'var(--accent-color)' }}>
          Active ({activeTasks.length})
        </button>
        <button className="flex-1 py-2 text-[15px] text-muted-foreground">
          Done ({completedTasks.length})
        </button>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar">
        {activeTasks.map(task => (
          <IOSProjectTaskRow key={task.id} task={task} />
        ))}
      </div>
    </div>
  );
}
