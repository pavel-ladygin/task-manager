import { useState } from 'react';
import { isTomorrow, isFuture, parseISO, format } from 'date-fns';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { Checkbox } from '@/components/shared/Checkbox';
import { PriorityIndicator } from '@/components/shared/PriorityIndicator';
import { ProjectPill } from '@/components/shared/ProjectPill';
import { EmptyState } from '@/components/shared/EmptyState';

function IOSUpcomingRow({ task }: { task: typeof import('@/data/mockData').tasks[0] }) {
  const { dispatch } = useApp();

  return (
    <div
      onClick={() => dispatch({ type: 'SELECT_IOS_TASK', taskId: task.id })}
      className="flex items-center gap-3 px-4 py-3.5 min-h-[56px] cursor-pointer hover:bg-secondary/30 transition-colors border-b border-border/50"
    >
      <Checkbox checked={task.status === 'done'} onToggle={() => dispatch({ type: 'TOGGLE_TASK_COMPLETE', taskId: task.id })} size={24} />
      <PriorityIndicator priority={task.priority} variant="dot" size={8} />
      <div className="flex-1 min-w-0">
        <p className={`text-[17px] ${task.status === 'done' ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
          {task.title}
        </p>
        <div className="flex items-center gap-2 mt-0.5">
          {task.projectId && <ProjectPill projectId={task.projectId} />}
        </div>
      </div>
    </div>
  );
}

export function IOSUpcomingScreen() {
  const { state } = useApp();
  const [mode, setMode] = useState<'list' | 'calendar'>('list');

  const upcomingTasks = state.tasks.filter(t => {
    if (t.status === 'done' || t.status === 'cancelled') return false;
    const date = t.scheduledDate || t.dueDate;
    if (!date) return false;
    const d = parseISO(date);
    return isFuture(d) || isTomorrow(d);
  });

  const grouped: Record<string, typeof upcomingTasks> = {};
  upcomingTasks.forEach(task => {
    const date = task.scheduledDate || task.dueDate;
    if (!date) return;
    const d = parseISO(date);
    let key: string;
    if (isTomorrow(d)) key = 'Tomorrow';
    else key = format(d, 'EEEE, MMM d');
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(task);
  });

  return (
    <div className="h-full flex flex-col">
      <div className="px-5 pt-2 pb-2">
        <h1 className="text-[34px] font-bold text-foreground tracking-tight">Upcoming</h1>
        <div className="flex bg-secondary rounded-lg p-0.5 mt-2">
          {(['list', 'calendar'] as const).map(m => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex-1 py-1 rounded-md text-[13px] font-medium transition-colors ${
                mode === m ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground'
              }`}
            >
              {m.charAt(0).toUpperCase() + m.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar">
        {mode === 'list' ? (
          Object.keys(grouped).length === 0 ? (
            <EmptyState icon={Calendar} title="No upcoming tasks" subtitle="Nothing scheduled ahead" />
          ) : (
            Object.entries(grouped).map(([date, tasks]) => (
              <div key={date}>
                <div className="px-4 py-2 bg-secondary/50 sticky top-0">
                  <span className="text-[13px] font-semibold text-foreground">{date}</span>
                  <span className="text-[12px] text-muted-foreground ml-1.5">({tasks.length})</span>
                </div>
                {tasks.map(task => <IOSUpcomingRow key={task.id} task={task} />)}
              </div>
            ))
          )
        ) : (
          <CalendarCompactView />
        )}
      </div>
    </div>
  );
}

function CalendarCompactView() {
  const { state } = useApp();
  const [selectedDay, setSelectedDay] = useState(0);

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const today = new Date().getDay();
  const adjustedToday = today === 0 ? 6 : today - 1;

  const dayTasks = state.tasks.filter(t => t.status !== 'done');

  return (
    <div>
      <div className="flex items-center justify-between px-4 py-2">
        <button><ChevronLeft size={18} className="text-muted-foreground" /></button>
        <span className="text-[13px] font-medium text-foreground">This Week</span>
        <button><ChevronRight size={18} className="text-muted-foreground" /></button>
      </div>

      <div className="flex justify-around px-2 py-2">
        {days.map((day, idx) => (
          <button
            key={day}
            onClick={() => setSelectedDay(idx)}
            className={`flex flex-col items-center gap-1 py-2 px-3 rounded-xl transition-colors ${
              selectedDay === idx ? 'bg-[var(--accent-color)]/10' : ''
            }`}
          >
            <span className="text-[11px] text-muted-foreground">{day}</span>
            <span
              className={`text-[17px] font-semibold w-8 h-8 flex items-center justify-center rounded-full ${
                selectedDay === idx
                  ? 'text-white'
                  : idx === adjustedToday
                  ? 'text-[var(--accent-color)]'
                  : 'text-foreground'
              }`}
              style={selectedDay === idx ? { backgroundColor: 'var(--accent-color)' } : {}}
            >
              {15 + idx}
            </span>
            {idx === adjustedToday && (
              <div className="w-1 h-1 rounded-full" style={{ backgroundColor: 'var(--accent-color)' }} />
            )}
          </button>
        ))}
      </div>

      <div className="px-4 mt-2">
        {dayTasks.slice(0, 5).map(task => (
          <IOSUpcomingRow key={task.id} task={task} />
        ))}
      </div>
    </div>
  );
}
