import { useApp } from '@/hooks/useAppContext';
import { Folder, ChevronRight } from 'lucide-react';
import { EmptyState } from '@/components/shared/EmptyState';

export function IOSProjectsScreen() {
  const { state, dispatch } = useApp();
  const activeProjects = state.projects.filter(p => p.status === 'active');

  return (
    <div className="h-full flex flex-col">
      <div className="px-5 pt-2 pb-3 flex items-center justify-between">
        <h1 className="text-[34px] font-bold text-foreground tracking-tight">Projects</h1>
      </div>
      <div className="flex-1 overflow-y-auto hide-scrollbar px-4 space-y-3">
        {activeProjects.length === 0 ? (
          <EmptyState icon={Folder} title="No projects" subtitle="Create your first project" />
        ) : (
          activeProjects.map(project => {
            const projectTasks = state.tasks.filter(t => t.projectId === project.id);
            const completed = projectTasks.filter(t => t.status === 'done').length;
            const total = projectTasks.length;
            const progress = total > 0 ? (completed / total) * 100 : 0;

            return (
              <button
                key={project.id}
                onClick={() => dispatch({ type: 'SELECT_IOS_PROJECT', projectId: project.id })}
                className="w-full flex items-center gap-3 bg-secondary/40 rounded-xl p-4 text-left hover:bg-secondary/60 transition-colors"
              >
                <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: project.color }} />
                <div className="flex-1 min-w-0">
                  <p className="text-[17px] font-medium text-foreground">{project.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-[60px] h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${progress}%`, backgroundColor: project.color }}
                      />
                    </div>
                    <span className="text-[12px] text-muted-foreground">{completed}/{total}</span>
                  </div>
                </div>
                <ChevronRight size={18} className="text-muted-foreground flex-shrink-0" />
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
