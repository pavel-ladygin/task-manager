import { useState } from 'react';
import { isPast, isToday, parseISO } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Plus, Search } from 'lucide-react';
import { useApp } from '@/hooks/useAppContext';
import { Checkbox } from '@/components/shared/Checkbox';
import { PriorityIndicator } from '@/components/shared/PriorityIndicator';
import { ProjectPill } from '@/components/shared/ProjectPill';
import { EmptyState } from '@/components/shared/EmptyState';
import { SectionHeader } from '@/components/shared/SectionHeader';
import { IOSTaskDetailSheet } from './IOSTaskDetailSheet';

function IOSTaskRow({ task }: { task: typeof import('@/data/mockData').tasks[0] }) {
  const { dispatch } = useApp();
  const isCompleted = task.status === 'done';
  const isOverdue = task.dueDate && isPast(parseISO(task.dueDate)) && !isToday(parseISO(task.dueDate)) && !isCompleted;

  const handleToggle = () => {
    dispatch({ type: 'TOGGLE_TASK_COMPLETE', taskId: task.id });
  };

  return (
    <div
      onClick={() => dispatch({ type: 'SELECT_IOS_TASK', taskId: task.id })}
      className="flex items-start gap-3 px-4 py-3 min-h-[56px] cursor-pointer hover:bg-secondary/30 transition-colors border-b border-border/50"
    >
      <div className="pt-0.5">
        <Checkbox checked={isCompleted} onToggle={handleToggle} size={24} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <PriorityIndicator priority={task.priority} variant="dot" size={8} />
          <span className={`text-[17px] leading-snug ${isCompleted ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
            {task.title}
          </span>
        </div>
        <div className="flex items-center gap-2 mt-1">
          {task.projectId && <ProjectPill projectId={task.projectId} />}
          {task.dueDate && (
            <span className={`text-[13px] ${isOverdue ? 'text-[var(--overdue)]' : 'text-muted-foreground'}`}>
              {new Date(task.dueDate).toLocaleDateString([], { month: 'short', day: 'numeric' })}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export function IOSTodayScreen() {
  const { state } = useApp();
  const [quickAddFocused, setQuickAddFocused] = useState(false);

  const overdue = state.tasks.filter(t =>
    t.dueDate && isPast(parseISO(t.dueDate)) && !isToday(parseISO(t.dueDate)) && t.status !== 'done' && t.status !== 'cancelled'
  );
  const todayTasks = state.tasks.filter(t =>
    (t.scheduledDate && isToday(parseISO(t.scheduledDate)) && t.status !== 'done' && t.status !== 'cancelled') ||
    (t.dueDate && isToday(parseISO(t.dueDate)) && t.status !== 'done' && t.status !== 'cancelled')
  );
  const later = state.tasks.filter(t =>
    ((t.scheduledDate && !isToday(parseISO(t.scheduledDate))) ||
    (t.dueDate && !isToday(parseISO(t.dueDate)))) &&
    t.status !== 'done' && t.status !== 'cancelled' && !overdue.includes(t)
  );
  const completed = state.tasks.filter(t => t.status === 'done');

  return (
    <div className="h-full flex flex-col">
      <div className="px-5 pt-2 pb-3 flex items-center justify-between">
        <h1 className="text-[34px] font-bold text-foreground tracking-tight">Today</h1>
        <button className="p-2">
          <Search size={20} className="text-muted-foreground" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar">
        {overdue.length === 0 && todayTasks.length === 0 && later.length === 0 ? (
          <EmptyState icon={Sun} title="You\'re all caught up" subtitle="No tasks for today" />
        ) : (
          <>
            {overdue.length > 0 && (
              <div>
                <SectionHeader title="Overdue" count={overdue.length} overdueTint />
                {overdue.map(task => <IOSTaskRow key={task.id} task={task} />)}
              </div>
            )}
            {todayTasks.length > 0 && (
              <div>
                <SectionHeader title="Today" count={todayTasks.length} />
                {todayTasks.map(task => <IOSTaskRow key={task.id} task={task} />)}
              </div>
            )}
            {later.length > 0 && (
              <div>
                <SectionHeader title="Later" count={later.length} />
                {later.map(task => <IOSTaskRow key={task.id} task={task} />)}
              </div>
            )}
            {completed.length > 0 && (
              <div>
                <SectionHeader title="Completed" count={completed.length} defaultCollapsed />
              </div>
            )}
          </>
        )}
      </div>

      <div className="absolute bottom-[65px] left-4 right-4 z-30 flex items-center gap-3">
        <motion.div
          animate={{ width: quickAddFocused ? '100%' : 'calc(100% - 64px)' }}
          className="h-12 bg-background rounded-xl shadow-md border border-border/50 flex items-center px-3"
        >
          <Plus size={20} style={{ color: 'var(--accent-color)' }} />
          <input
            type="text"
            placeholder="Add a task..."
            onFocus={() => setQuickAddFocused(true)}
            onBlur={() => setQuickAddFocused(false)}
            className="flex-1 ml-2 bg-transparent text-[17px] outline-none placeholder:text-muted-foreground"
          />
        </motion.div>
        {!quickAddFocused && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg flex-shrink-0"
            style={{ backgroundColor: 'var(--accent-color)' }}
          >
            <Plus size={28} />
          </motion.button>
        )}
      </div>

      <AnimatePresence>
        {state.iosScreen === 'task_detail' && state.iosSelectedTaskId && (
          <IOSTaskDetailSheet />
        )}
      </AnimatePresence>
    </div>
  );
}
