import { useApp } from '@/hooks/useAppContext';
import { CheckCircle, Sun, Moon, Bell, Database, Info, ChevronRight } from 'lucide-react';

function SettingsGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-6">
      <h3 className="text-[13px] font-medium text-muted-foreground uppercase tracking-wider mb-2 px-5">{title}</h3>
      <div className="mx-4 rounded-xl bg-secondary/40 divide-y divide-border/30 overflow-hidden">
        {children}
      </div>
    </div>
  );
}

function SettingsRow({ label, icon: Icon, children, onClick }: {
  label: string;
  icon?: React.ElementType;
  children?: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center justify-between px-4 py-3 text-left"
    >
      <div className="flex items-center gap-3">
        {Icon && <Icon size={18} className="text-muted-foreground" />}
        <span className="text-[17px] text-foreground">{label}</span>
      </div>
      <div className="flex items-center gap-1">
        {children}
        {!children && <ChevronRight size={16} className="text-muted-foreground" />}
      </div>
    </button>
  );
}

function Toggle({ checked }: { checked: boolean }) {
  return (
    <div
      className={`relative w-[51px] h-[31px] rounded-full transition-colors duration-200 ${
        checked ? '' : 'bg-muted'
      }`}
      style={checked ? { backgroundColor: 'var(--accent-color)' } : {}}
    >
      <div
        className={`absolute top-[2px] w-[27px] h-[27px] rounded-full bg-white shadow-sm transition-transform duration-200 ${
          checked ? 'translate-x-[22px]' : 'translate-x-[2px]'
        }`}
      />
    </div>
  );
}

export function IOSSettingsScreen() {
  const { state, dispatch } = useApp();

  return (
    <div className="h-full flex flex-col">
      <div className="px-5 pt-2 pb-3">
        <h1 className="text-[34px] font-bold text-foreground tracking-tight">Settings</h1>
      </div>
      <div className="flex-1 overflow-y-auto hide-scrollbar">
        <div className="flex flex-col items-center py-6">
          <div
            className="w-20 h-20 rounded-[22px] flex items-center justify-center mb-3 shadow-lg"
            style={{ background: 'linear-gradient(135deg, #4F5BD5, #8B5CF6)' }}
          >
            <CheckCircle size={40} className="text-white" />
          </div>
          <p className="text-[17px] font-semibold text-foreground">Focus</p>
          <p className="text-[13px] text-muted-foreground">Version 1.0</p>
        </div>

        <SettingsGroup title="Appearance">
          <SettingsRow label="Theme" icon={state.theme === 'dark' ? Moon : Sun}>
            <div className="flex bg-secondary rounded-lg p-0.5">
              <button
                onClick={() => dispatch({ type: 'SET_THEME', theme: 'light' })}
                className={`px-3 py-1 rounded-md text-[12px] ${state.theme === 'light' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
              >
                Light
              </button>
              <button
                onClick={() => dispatch({ type: 'SET_THEME', theme: 'dark' })}
                className={`px-3 py-1 rounded-md text-[12px] ${state.theme === 'dark' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
              >
                Dark
              </button>
            </div>
          </SettingsRow>
        </SettingsGroup>

        <SettingsGroup title="Notifications">
          <SettingsRow label="Enable Notifications" icon={Bell}>
            <Toggle checked={true} />
          </SettingsRow>
          <SettingsRow label="Daily Summary" icon={Bell}>
            <Toggle checked={true} />
          </SettingsRow>
        </SettingsGroup>

        <SettingsGroup title="Data">
          <SettingsRow label="Export Tasks" icon={Database} />
          <SettingsRow label="Import Tasks" icon={Database} />
        </SettingsGroup>

        <SettingsGroup title="About">
          <SettingsRow label="Send Feedback" icon={Info} />
          <SettingsRow label="Privacy Policy" icon={Info} />
        </SettingsGroup>
      </div>
    </div>
  );
}
