import { useApp } from '@/hooks/useAppContext';
import { Inbox } from 'lucide-react';
import { Checkbox } from '@/components/shared/Checkbox';
import { PriorityIndicator } from '@/components/shared/PriorityIndicator';
import { EmptyState } from '@/components/shared/EmptyState';

function IOSInboxRow({ task }: { task: typeof import('@/data/mockData').tasks[0] }) {
  const { dispatch } = useApp();

  return (
    <div
      onClick={() => dispatch({ type: 'SELECT_IOS_TASK', taskId: task.id })}
      className="flex items-center gap-3 px-4 py-3.5 min-h-[56px] cursor-pointer hover:bg-secondary/30 transition-colors border-b border-border/50"
    >
      <Checkbox checked={task.status === 'done'} onToggle={() => dispatch({ type: 'TOGGLE_TASK_COMPLETE', taskId: task.id })} size={24} />
      <PriorityIndicator priority={task.priority} variant="dot" size={8} />
      <div className="flex-1 min-w-0">
        <p className={`text-[17px] ${task.status === 'done' ? 'text-[var(--completed)] line-through' : 'text-foreground'}`}>
          {task.title}
        </p>
        <p className="text-[13px] text-muted-foreground mt-0.5">
          {new Date(task.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
        </p>
      </div>
    </div>
  );
}

export function IOSInboxScreen() {
  const { state } = useApp();
  const inboxTasks = state.tasks.filter(t => t.status === 'inbox');

  return (
    <div className="h-full flex flex-col">
      <div className="px-5 pt-2 pb-3">
        <h1 className="text-[34px] font-bold text-foreground tracking-tight">Inbox</h1>
      </div>
      <div className="flex-1 overflow-y-auto hide-scrollbar">
        {inboxTasks.length === 0 ? (
          <EmptyState icon={Inbox} title="Inbox Zero" subtitle="All tasks have been processed" />
        ) : (
          inboxTasks.map(task => <IOSInboxRow key={task.id} task={task} />)
        )}
      </div>
    </div>
  );
}
