import { createContext, useContext, useReducer, type ReactNode } from 'react';
import type { AppState, AppAction } from '@/types';
import { tasks, projects } from '@/data/mockData';

const initialState: AppState = {
  tasks,
  projects,
  selectedTaskId: '3',
  selectedView: 'today',
  selectedProjectId: null,
  sidebarCollapsed: false,
  detailVisible: true,
  theme: 'light',
  iosTab: 'today',
  iosScreen: 'today',
  iosSelectedTaskId: null,
  iosSelectedProjectId: null,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SELECT_TASK':
      return { ...state, selectedTaskId: action.taskId };
    case 'SELECT_VIEW':
      return {
        ...state,
        selectedView: action.view,
        selectedProjectId: action.view === 'project_detail' ? state.selectedProjectId : null,
        detailVisible: action.view !== 'settings' && action.view !== 'kanban' && action.view !== 'calendar',
      };
    case 'SELECT_PROJECT':
      return {
        ...state,
        selectedProjectId: action.projectId,
        selectedView: 'project_detail',
        detailVisible: true,
      };
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarCollapsed: !state.sidebarCollapsed };
    case 'TOGGLE_DETAIL':
      return { ...state, detailVisible: !state.detailVisible };
    case 'SET_THEME':
      return { ...state, theme: action.theme };
    case 'SET_IOS_TAB':
      return {
        ...state,
        iosTab: action.tab,
        iosScreen: action.tab,
        iosSelectedTaskId: null,
      };
    case 'SET_IOS_SCREEN':
      return { ...state, iosScreen: action.screen };
    case 'SELECT_IOS_TASK':
      return {
        ...state,
        iosSelectedTaskId: action.taskId,
        iosScreen: action.taskId ? 'task_detail' : state.iosScreen,
      };
    case 'SELECT_IOS_PROJECT':
      return {
        ...state,
        iosSelectedProjectId: action.projectId,
        iosScreen: action.projectId ? 'project_detail_ios' : 'projects',
      };
    case 'TOGGLE_TASK_COMPLETE': {
      const task = state.tasks.find(t => t.id === action.taskId);
      if (!task) return state;
      const isDone = task.status === 'done';
      return {
        ...state,
        tasks: state.tasks.map(t =>
          t.id === action.taskId
            ? {
                ...t,
                status: isDone ? 'planned' : 'done',
                completedAt: isDone ? null : new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              }
            : t
        ),
      };
    }
    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(t =>
          t.id === action.taskId ? { ...t, ...action.updates, updatedAt: new Date().toISOString() } : t
        ),
      };
    case 'ADD_TASK':
      return { ...state, tasks: [action.task, ...state.tasks] };
    case 'DELETE_TASK':
      return {
        ...state,
        tasks: state.tasks.filter(t => t.id !== action.taskId),
        selectedTaskId: state.selectedTaskId === action.taskId ? null : state.selectedTaskId,
      };
    case 'MOVE_TASK_STATUS':
      return {
        ...state,
        tasks: state.tasks.map(t =>
          t.id === action.taskId
            ? {
                ...t,
                status: action.status,
                completedAt: action.status === 'done' ? new Date().toISOString() : t.completedAt,
                updatedAt: new Date().toISOString(),
              }
            : t
        ),
      };
    default:
      return state;
  }
}

const AppContext = createContext<{ state: AppState; dispatch: React.Dispatch<AppAction> } | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);
  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
