export type TaskStatus = 'inbox' | 'planned' | 'in_progress' | 'done' | 'cancelled';
export type Priority = 'none' | 'low' | 'medium' | 'high' | 'urgent';
export type Theme = 'light' | 'dark';
export type MacOSView = 'today' | 'inbox' | 'upcoming' | 'kanban' | 'calendar' | 'project_detail' | 'completed' | 'settings';
export type IOSTab = 'today' | 'inbox' | 'upcoming' | 'projects' | 'settings';
export type IOSScreen = 'today' | 'inbox' | 'upcoming' | 'projects' | 'settings' | 'task_detail' | 'project_detail_ios';

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  priority: Priority;
  scheduledDate: string | null;
  dueDate: string | null;
  projectId: string | null;
  notes: string;
  checklist: ChecklistItem[];
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export interface Project {
  id: string;
  name: string;
  color: string;
  colorDark: string;
  status: 'active' | 'archived';
  deadline: string | null;
  notes: string;
}

export interface AppState {
  tasks: Task[];
  projects: Project[];
  selectedTaskId: string | null;
  selectedView: MacOSView;
  selectedProjectId: string | null;
  sidebarCollapsed: boolean;
  detailVisible: boolean;
  theme: Theme;
  iosTab: IOSTab;
  iosScreen: IOSScreen;
  iosSelectedTaskId: string | null;
  iosSelectedProjectId: string | null;
}

export type AppAction =
  | { type: 'SELECT_TASK'; taskId: string | null }
  | { type: 'SELECT_VIEW'; view: MacOSView }
  | { type: 'SELECT_PROJECT'; projectId: string | null }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'TOGGLE_DETAIL' }
  | { type: 'SET_THEME'; theme: Theme }
  | { type: 'SET_IOS_TAB'; tab: IOSTab }
  | { type: 'SET_IOS_SCREEN'; screen: IOSScreen }
  | { type: 'SELECT_IOS_TASK'; taskId: string | null }
  | { type: 'SELECT_IOS_PROJECT'; projectId: string | null }
  | { type: 'TOGGLE_TASK_COMPLETE'; taskId: string }
  | { type: 'UPDATE_TASK'; taskId: string; updates: Partial<Task> }
  | { type: 'ADD_TASK'; task: Task }
  | { type: 'DELETE_TASK'; taskId: string }
  | { type: 'MOVE_TASK_STATUS'; taskId: string; status: TaskStatus };
