# Focus — Technical Specification

## Development Environment

- **Project name**: focus-planner
- **Root directory**: /mnt/agents/output/app
- **Package manager**: npm (Node 20+)

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^18.3.0 | UI framework |
| react-dom | ^18.3.0 | DOM renderer |
| framer-motion | ^11.15.0 | View transitions, panel slides, spring physics, layout animations |
| lucide-react | ^0.468.0 | Icon library (Apple-aesthetic icons matching SF Symbol style) |
| date-fns | ^4.1.0 | Date formatting and calendar calculations |
| clsx | ^2.1.0 | Conditional classnames |
| tailwind-merge | ^2.6.0 | Tailwind class deduplication |
| class-variance-authority | ^0.7.0 | Component variant management |

## Component Inventory

### macOS Components

| Component | Source | Notes |
|-----------|--------|-------|
| MacOSWindow | Custom | Main window chrome — title bar with traffic lights, resizable container, three-column layout (sidebar / main / detail). Liquid Glass toolbar. |
| Sidebar | Custom | Left navigation panel with Liquid Glass material. Contains SidebarItem list, collapsible to icon-only mode (72px). |
| SidebarItem | Custom | Individual nav item with icon, label, optional badge. Supports default/hover/selected/focus states with accent tint. |
| Toolbar | Custom | Top bar with left (sidebar toggle, view title, count), center (search field), right (sort, filter, add) zones. |
| TodayView | Custom | Today task list with four sticky sections (Overdue, Today, Later, Completed). Uses TaskRow and SectionHeader. |
| InboxView | Custom | Flat task list with hover-reveal triage actions (project, schedule, priority). Quick-add at top. |
| KanbanView | Custom | Horizontal scroll board with 5 fixed-width columns (280px). Uses TaskCard. Drag-and-drop between columns. |
| CalendarView | Custom | Week grid (Mon-Sun, 30-min slots, 24h). All-day row at top. Current time indicator. Task blocks positioned by time. |
| ProjectDetailView | Custom | Project header (name, status, deadline, progress bar, notes) + task list (Active/Completed sections). |
| SettingsView | Custom | Single-column scrollable settings form with grouped sections. Segmented controls, toggles, dropdowns. |
| TaskRow | Custom | macOS list item — checkbox, priority dot, title, project pill, scheduled time, due date. 44px height. |
| TaskCard | Custom | Kanban card — project pill, priority, title, dates, checklist indicator. 12px radius, shadow-sm. |
| DetailInspector | Custom | Right panel (340px) with editable title, status pills, priority selector, project dropdown, date pickers, checklist, notes, metadata. |
| SectionHeader | Custom | Sticky section divider with title, count badge, collapsible chevron. |
| QuickAddField | Custom | Expandable input with plus icon, action buttons (project, schedule, priority). 40px height, 8px radius. |
| ProjectPill | Custom | Colored badge — project color at 15% bg + tinted text. 20px height, pill radius. |
| StatusPill | Custom | Toggle pill for 5 statuses. Inactive: secondary bg. Active: accent bg + white text. |
| PriorityIndicator | Custom | Dot (8px) or flag icon, colored by priority level. Urgent variant adds 2px ring. |
| Checkbox | Custom | 20px circle with animated fill and checkmark stroke-draw on toggle. |
| SearchField | Custom | 280px expandable input with magnifying glass icon, clear button. Pill-shaped, secondary bg. |

### iOS Components

| Component | Source | Notes |
|-----------|--------|-------|
| iOSFrame | Custom | Phone mockup bezel with screen area, home indicator, dynamic island notch. Fixed 390×844 screen. |
| IOSTabBar | Custom | Bottom tab bar (Liquid Glass) with 5 tabs. Floating action button above. |
| iOSTodayScreen | Custom | Large title "Today", scrollable sections (Overdue, Today, Later, Completed), floating quick-add + FAB. |
| iOSInboxScreen | Custom | Large title "Inbox", flat list with enhanced swipe actions (complete, schedule, priority, delete). |
| iOSUpcomingScreen | Custom | Large title "Upcoming", segmented List/Calendar, date-grouped task list. |
| iOSProjectsScreen | Custom | Large title "Projects", project cards with progress bars, pushed detail view. |
| iOSSettingsScreen | Custom | Large title "Settings", grouped iOS table style sections. |
| iOSTaskDetailSheet | Custom | Bottom sheet (95% height) with handle, full task editing form. Spring presentation animation. |
| iOSTaskRow | Custom | iOS list item — larger touch targets (56px), 24px checkbox, Body 17px title. |
| iOSQuickAdd | Custom | Floating input above tab bar + FAB. Expands on tap. |

### Shared Components

| Component | Source | Notes |
|-----------|--------|-------|
| ThemeProvider | Custom | React context providing light/dark mode, color tokens, and glass material styles. |
| EmptyState | Custom | SF Symbol icon (48px, 30% opacity) + title + subtitle + optional action button. |
| AppIcon | Custom | SVG app icon for macOS window and iOS frame. |

## Animation Implementation

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Panel slide (detail inspector) | Framer Motion | `AnimatePresence` + `motion.div` with `x: 340 → 0`, spring transition | Low |
| View content transition | Framer Motion | `AnimatePresence` + `motion.div` with `opacity` + `y: 4 → 0` fade-in, 0.25s ease-out | Low |
| Checkbox toggle | Framer Motion | `motion.circle` scale from center for fill, `motion.path` stroke-dashoffset draw for checkmark | Medium |
| Task completion strikethrough | CSS | `::after` pseudo-element width animation 0% → 100%, 0.2s ease | Low |
| Completion row flash | Framer Motion | Brief `backgroundColor` pulse to success/8%, 0.1s | Low |
| Section collapse/expand | Framer Motion | `AnimatePresence` + `motion.div` height auto animation with `overflow: hidden` | Medium |
| Kanban card drag | Framer Motion | `Reorder` component or `motion.div` with `drag` prop, scale 1.02 + rotate 2deg + shadow-lg on drag | Medium |
| Kanban card drop | Framer Motion | Snap to position with spring bounce on release, staggered 0.03s column re-flow | Medium |
| Kanban hover lift | CSS | `translateY(-1px)` + shadow-md transition, 0.2s | Low |
| iOS bottom sheet | Framer Motion | `motion.div` with `y: 100% → 5%` spring(1, 80, 10, 0), backdrop opacity fade | Medium |
| iOS sheet content stagger | Framer Motion | `staggerChildren: 0.03` on container, `opacity` + `y: 8 → 0` per section | Low |
| Triage slide-out | Framer Motion | `AnimatePresence` + `motion.div` with `opacity: 0` + `x: -20` exit animation, 0.3s | Low |
| Toolbar search expand | CSS | `width` transition 280px → 340px, 0.2s ease | Low |
| Progress bar fill | Framer Motion | `motion.div` with `width` animated from 0% to target, 0.4s ease-out on view entry | Low |
| Status pill selection | Framer Motion | `scale: 0.95 → 1.0` spring bounce on active state change | Low |
| Empty state appear | Framer Motion | Fade in + `y: 8 → 0`, 0.25s ease-out | Low |
| Calendar time indicator | CSS | 1px line positioned absolutely, updated every minute via `setInterval` | Low |
| iOS FAB pulse | Framer Motion | Subtle `scale` animation loop — idle pulse effect | Low |
| Sidebar collapse | Framer Motion | `animate={{ width: collapsed ? 72 : 220 }}` with spring | Low |
| Glass material specular | CSS | `backdrop-filter: blur()` + semi-transparent bg. No real-time mouse tracking needed for static concept. | Low |

## State & Logic Plan

### Data Model

Three core entity types: Task, Project, AppState.

**Task fields**: id (string), title (string), status (enum: inbox/planned/in_progress/done/cancelled), priority (enum: none/low/medium/high/urgent), scheduledDate (Date | null), dueDate (Date | null), projectId (string | null), notes (string), checklist (array of {id, text, completed}), createdAt (Date), updatedAt (Date), completedAt (Date | null).

**Project fields**: id (string), name (string), color (string hex), status (enum: active/archived), deadline (Date | null), notes (string).

### State Architecture

Single React context `AppContext` with `useReducer` managing:

- `tasks`: Task[] — all tasks
- `projects`: Project[] — all projects
- `selectedTaskId`: string | null
- `selectedView`: View enum (today/inbox/kanban/calendar/projects/completed/settings)
- `selectedProjectId`: string | null (for project detail view)
- `sidebarCollapsed`: boolean
- `detailVisible`: boolean
- `theme`: Theme enum (light/dark)
- `iosTab`: IOSTab enum
- `iosScreen`: IOSScreen enum (for navigation within iOS frame)

### Business Logic

- **View-specific task filtering**: Today view filters by date (overdue, today, later, completed). Inbox shows status === 'inbox'. Kanban groups by status. Calendar filters by scheduled date.
- **Task completion**: Toggle sets status, updates completedAt, triggers completion animation sequence.
- **Kanban drag-and-drop**: Reorder items within column (status change) using Framer Motion Reorder or manual drag state tracking.
- **Search**: Client-side text filtering across task titles, projects, notes.
- **Date grouping**: Tasks grouped by date using date-fns isToday/isTomorrow/isPast comparisons.
- **iOS navigation**: Tab bar switches between Today/Inbox/Upcoming/Projects/Settings screens. Task detail opens as bottom sheet overlay.

### Mock Data Strategy

Pre-populated with 15-20 realistic tasks across 5-8 projects to demonstrate all views, statuses, priorities, and date scenarios including overdue tasks.

## Other Key Decisions

### Presentation Architecture

The deliverable is a **scrollable design showcase page** with two major sections:

1. **macOS Desktop Simulation** (top section): A full-viewport macOS window with working sidebar navigation switching between Today, Inbox, Kanban, Calendar, Project Detail, and Settings views. Detail inspector toggles on task selection. Fully interactive as a design prototype.

2. **iOS Companion Section** (below): A centered iPhone mockup frame showing the iOS app with working tab bar navigation (Today, Inbox, Upcoming, Projects, Settings) and task detail bottom sheet.

### Icon Strategy

Use **lucide-react** throughout. Lucide icons are clean, minimal, and geometrically similar to SF Symbols. Map key icons: `Sun` → Today, `Inbox` → Inbox, `Calendar` → Upcoming/Calendar, `LayoutTemplate` → Kanban, `Folder` → Projects, `CheckCircle` → Completed, `Settings` → Settings, `Circle`/`CheckCircle2` → Checkbox, `Flag` → Priority, `Clock` → Scheduled, `Search` → Search, `Plus` → Add, `ChevronRight`/`ChevronLeft` → Navigation, `MoreHorizontal` → More actions.

### Glass Material Implementation

Liquid Glass effect achieved through layered CSS:
- `background: rgba(255, 255, 255, 0.15)` (light) / `rgba(28, 28, 30, 0.4)` (dark)
- `backdrop-filter: blur(20px) saturate(180%)`
- `border-bottom: 1px solid rgba(255, 255, 255, 0.1)` for subtle edge
- Subtle `box-shadow: 0 0 1px rgba(0,0,0,0.1), 0 4px 20px rgba(0,0,0,0.04)` for glass edge refraction

### No Backend

Pure client-side mock data. No API calls, no database, no server. This is a visual design concept, not a functional application.
